import React from 'react';
import { Link } from 'react-router-dom'; // Import the Link component

const Navbar = () => {
  return (
    <nav className="navbar bg-white shadow-md bg-purple-600 py-4 w-full">
      <div className="flex justify-center w-full">
        <Link to="/" className="text-2xl text-white font-semibold">
          Story Path
        </Link>
      </div>
    </nav>
  );
};

export default Navbar;
