import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import '../App.css'; // Import CSS, one level up
import Navbar from '../components/navbar'; // Import Navbar component
import ProjectList from './projectlist'; // Import ProjectList from pages
import LocationList from './locationlist'; // Import LocationList from pages
import AddProject from './addproject'; // Import AddProject component
import LandingPage from './landingpage'; // Import LandingPage
import Footer from '../components/Footer';
import AddLocation from './addlocation'; // Import AddLocation component
import { useState } from 'react';

function App() {
  const [projects, setProjects] = useState([]);
  const [locations, setLocations] = useState([]); // Initial state with an empty array for locations

  // Function to add new project
  const addNewProject = (newProject) => {
    setProjects([...projects, { ...newProject, id: projects.length + 1 }]);
  };

  // Function to delete a project
  const deleteProject = (id) => {
    setProjects(projects.filter((project) => project.id !== id));
  };

  // Function to add a new location
  const addNewLocation = (newLocation) => {
    setLocations([...locations, { ...newLocation, id: locations.length + 1 }]);
  };

  // Function to delete a location
  const deleteLocation = (id) => {
    setLocations(locations.filter((location) => location.id !== id));
  };

  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route
          path="/projects"
          element={<ProjectList projects={projects} deleteProject={deleteProject} />}
        />
        <Route
          path="/projects/:id/locations"
          element={<LocationList locations={locations} deleteLocation={deleteLocation} />}
        />
        <Route path="/add-project" element={<AddProject addNewProject={addNewProject} />} />
        <Route
          path="/add-location"
          element={<AddLocation addNewLocation={addNewLocation} />}
        />
      </Routes>
      <Footer />
    </Router>
  );
}

export default App;
