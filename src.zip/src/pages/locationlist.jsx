import React from 'react';
import { Link } from 'react-router-dom'; // Import Link for navigation

function LocationList({ locations, deleteLocation }) {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="py-8">
          <h2 className="text-4xl font-bold text-blue-500 mb-6">The Locations List</h2>
          <div className="flex justify-center mb-6">
            <Link to="/add-location">
              <button className="mb-6 bg-blue-600 text-white font-medium py-2 px-4 rounded-lg shadow hover:bg-blue-700 transition duration-300 ease-in-out">
                Add Location
              </button>
            </Link>
          </div>

          {/* Locations List */}
          {locations.length === 0 ? (
            <p className="text-lg text-gray-600">No locations found.</p>
          ) : (
            <ul className="space-y-4">
              {locations.map((location) => (
                <li
                  key={location.id}
                  className="bg-white shadow-md rounded-lg p-4 border border-gray-200"
                >
                  <div className="flex justify-between items-center">
                    <div className="text-left">
                      <h3 className="text-xl font-semibold text-gray-800">{location.name}</h3>
                      <p className="text-gray-600">Trigger: {location.trigger}</p>
                      <p className="text-gray-600">Position: {location.position}</p>
                      <p className="text-gray-600">Points: {location.points}</p>
                    </div>
                    <div className="text-right flex space-x-2">
                      <button className="text-gray-500 border border-gray-300 px-3 py-1 rounded-lg shadow hover:bg-gray-100">
                        Edit
                      </button>
                      <button
                        className="text-red-500 border border-red-300 px-3 py-1 rounded-lg shadow hover:bg-red-100"
                        onClick={() => deleteLocation(location.id)} // Call the deleteLocation function
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}

export default LocationList;
