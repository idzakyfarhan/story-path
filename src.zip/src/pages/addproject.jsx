import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function AddProject({ addNewProject }) {
  const [project, setProject] = useState({
    title: '',
    description: '',
    instructions: '',
    initialClue: '',
    homescreenDisplay: 'Display initial clue',
    participantScoring: 'Number of Scanned QR Codes',
    published: false,
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setProject((prevProject) => ({
      ...prevProject,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    addNewProject(project);
    navigate('/projects'); // Redirect back to project list
  };

  const handleCancel = () => {
    navigate('/projects'); // Navigate back to the project list without saving
  };


  return (
    <div className="min-h-screen bg-gray-100 px-6 py-10">
      <div className="max-w-4xl mx-auto bg-white shadow-lg rounded-lg p-8">
        <h2 className="text-4xl font-bold text-blue-500 mb-10">Add New Project</h2>
        <form onSubmit={handleSubmit} className="space-y-8">
          
          {/* Title */}
          <div className="flex flex-col">
            <label htmlFor="title" className="block text-sm font-medium text-gray-700">
              Title
            </label>
            <input
              type="text"
              name="title"
              id="title"
              value={project.title}
              onChange={handleChange}
              className="mt-1 w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm p-2"
              placeholder="Enter the name of your project."
            />
          </div>

          {/* Description */}
          <div className="flex flex-col">
            <label htmlFor="description" className="block text-sm font-medium text-gray-700">
              Description
            </label>
            <textarea
              name="description"
              id="description"
              value={project.description}
              onChange={handleChange}
              className="mt-1 w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm p-2"
              placeholder="Provide a brief description of your project."
              rows="3"
            ></textarea>
            <p className="text-gray-500 text-sm mt-1">This is not displayed to participants.</p>
          </div>

          {/* Instructions */}
          <div className="flex flex-col">
            <label htmlFor="instructions" className="block text-sm font-medium text-gray-700">
              Instructions
            </label>
            <textarea
              name="instructions"
              id="instructions"
              value={project.instructions}
              onChange={handleChange}
              className="mt-1 w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm p-2"
              placeholder="Instructions for participants."
              rows="4"
            ></textarea>
            <p className="text-gray-500 text-sm mt-1">Explain how to engage with the project.</p>
          </div>

          {/* Initial Clue */}
          <div className="flex flex-col">
            <label htmlFor="initialClue" className="block text-sm font-medium text-gray-700">
              Initial Clue
            </label>
            <input
              type="text"
              name="initialClue"
              id="initialClue"
              value={project.initialClue}
              onChange={handleChange}
              className="mt-1 w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm p-2"
              placeholder="The first clue to start the project."
            />
          </div>

          {/* Homescreen Display */}
          <div className="flex flex-col">
            <label htmlFor="homescreenDisplay" className="block text-sm font-medium text-gray-700">
              Homescreen Display
            </label>
            <select
              name="homescreenDisplay"
              id="homescreenDisplay"
              value={project.homescreenDisplay}
              onChange={handleChange}
              className="mt-1 w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm p-2"
            >
              <option>Display initial clue</option>
              <option>Display project description</option>
            </select>
          </div>

          {/* Participant Scoring */}
          <div className="flex flex-col">
            <label htmlFor="participantScoring" className="block text-sm font-medium text-gray-700">
              Participant Scoring
            </label>
            <select
              name="participantScoring"
              id="participantScoring"
              value={project.participantScoring}
              onChange={handleChange}
              className="mt-1 w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 text-sm p-2"
            >
              <option>Number of Scanned QR Codes</option>
              <option>Points Earned</option>
            </select>
          </div>

          {/* Published */}
          <div className="flex items-start">
            <input
              id="published"
              name="published"
              type="checkbox"
              checked={project.published}
              onChange={handleChange}
              className="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300 rounded"
            />
            <label htmlFor="published" className="ml-3 text-sm font-medium text-gray-700">
              Published
            </label>
          </div>

          {/* Save Project Button */}
          <button
            type="submit"
            className="bg-blue-600 text-white font-medium py-2 px-4 rounded-lg shadow hover:bg-blue-700 transition duration-300 ease-in-out"
          >
            Save Project
          </button>
          <button
              type="button"
              onClick={handleCancel}
              className="bg-red-500 text-white font-medium py-2 px-4 rounded-lg shadow hover:bg-red-600 ml-2 transition duration-300 ease-in-out"
            >
              Cancel
          </button>
        </form>
      </div>
    </div>
  );
}

export default AddProject;
