import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

function AddLocation({ addNewLocation }) {
  const [location, setLocation] = useState({
    name: '',
    trigger: 'Location',
    position: '',
    points: '',
    clue: '',
    content: '',
  });

  const navigate = useNavigate();

  const handleChange = (e) => {
    const { name, value } = e.target;
    setLocation((prevLocation) => ({
      ...prevLocation,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    addNewLocation(location); // Add the new location
    navigate('/projects/1/locations'); // Redirect back to location list after saving
  };

  const handleCancel = () => {
    navigate('/projects/1/locations'); // Navigate back to the location list without saving
  };

  return (
    <div className="min-h-screen bg-gray-100 px-6 py-10">
      <div className="max-w-4xl mx-auto bg-white shadow-lg rounded-lg p-8">
        <h2 className="text-4xl font-bold text-blue-500 mb-10">Add New Location</h2>
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Location Name */}
          <div className="flex flex-col">
            <label htmlFor="name" className="block text-left text-sm font-medium text-gray-700">
              Location Name
            </label>
            <input
              type="text"
              name="name"
              id="name"
              value={location.name}
              onChange={handleChange}
              className="mt-1 w-full border border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500 text-sm p-2"
              placeholder="The name of this location."
            />
          </div>

          {/* Location Trigger */}
          <div className="flex flex-col">
            <label htmlFor="trigger" className="block text-left text-sm font-medium text-gray-700">
              Location Trigger
            </label>
            <select
              name="trigger"
              id="trigger"
              value={location.trigger}
              onChange={handleChange}
              className="mt-1 w-full border border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500 text-sm p-2"
            >
              <option>Location</option>
              <option>QR Code</option>
              <option>Both</option>
            </select>
          </div>

          {/* Location Position */}
          <div className="flex flex-col">
            <label htmlFor="position" className="block text-left text-sm font-medium text-gray-700">
              Location Position (lat, long)
            </label>
            <input
              type="text"
              name="position"
              id="position"
              value={location.position}
              onChange={handleChange}
              className="mt-1 w-full border border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500 text-sm p-2"
              placeholder="Enter the latitude and longitude for this location."
            />
          </div>

          {/* Points for Reaching Location */}
          <div className="flex flex-col">
            <label htmlFor="points" className="block text-left text-sm font-medium text-gray-700">
              Points for Reaching Location
            </label>
            <input
              type="number"
              name="points"
              id="points"
              value={location.points}
              onChange={handleChange}
              className="mt-1 w-full border border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500 text-sm p-2"
              placeholder="Enter the number of points."
            />
          </div>

          {/* Clue */}
          <div className="flex flex-col">
            <label htmlFor="clue" className="block text-left text-sm font-medium text-gray-700">
              Clue
            </label>
            <input
              type="text"
              name="clue"
              id="clue"
              value={location.clue}
              onChange={handleChange}
              className="mt-1 w-full border border-gray-300 rounded-md shadow-sm focus:ring-purple-500 focus:border-purple-500 text-sm p-2"
              placeholder="Enter the clue that leads to the next location."
            />
          </div>

          {/* Save Location Button */}
          <button
            type="submit"
            className="bg-blue-500 text-white font-medium py-2 px-4 rounded-lg shadow hover:bg-blue-600 transition duration-300 ease-in-out"
          >
            Save Location
          </button>
          <button
              type="button"
              onClick={handleCancel}
              className="bg-red-500 text-white font-medium py-2 px-4 rounded-lg shadow hover:bg-red-600 ml-2 transition duration-300 ease-in-out"
            >
              Cancel
          </button>
        </form>
      </div>
    </div>
  );
}

export default AddLocation;
